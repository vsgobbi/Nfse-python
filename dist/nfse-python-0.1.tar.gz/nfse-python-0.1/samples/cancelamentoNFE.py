# -*- coding: utf-8 -*-
from services.Services import Services

objServ = Services()
print(objServ.cancelaNFe(cnpj="20018183000180", inscricao="57038597", nfe="153"))
