# -*- coding: utf-8 -*-
from services.Services import Services

objServ = Services()
print(objServ.envioRPS(cnpj="20018183000180",
                 serieRPS="28",
                 numeroRPS="4201",
                 tipoRPS="RPS",
                 dtEmissao="2019-07-02",
                 statusRPS="N",
                 tributacaoRPS="T",
                 valorServicos="200",
                 valorDeducoes="0",
                 valorPis="0",
                 valorCofins="0",
                 valorINSS="0",
                 codigoServico="02660",
                 aliquota="10",
                 cnpjTomador="30134945000167",
                 razaoSocialTomador="HUMMINGBIRD HEALTH PRODUCTS",
                 logradouro="Rua dos Ingleses",
                 numero="586",
                 complemento="Apto 63",
                 bairro="Morro dos Ingleses",
                 cep="01329000",
                 email="developers@starkbank.com",
                 discriminacao="Envio de Nota Fiscal de Servico Teste"
                 ))
